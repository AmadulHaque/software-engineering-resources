<?php

namespace App\Http\Resources;

class PermissionResource extends BaseJsonResource
{
}
