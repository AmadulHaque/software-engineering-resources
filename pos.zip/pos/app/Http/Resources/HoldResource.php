<?php

namespace App\Http\Resources;

/**
 * Class HoldResource
 */
class HoldResource extends BaseJsonResource
{
}
