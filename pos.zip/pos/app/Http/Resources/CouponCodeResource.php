<?php

namespace App\Http\Resources;

/**
 * Class CouponCodeResource
 */
class CouponCodeResource extends BaseJsonResource
{
}
