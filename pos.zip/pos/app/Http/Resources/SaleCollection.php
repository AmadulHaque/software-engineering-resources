<?php

namespace App\Http\Resources;

/**
 * Class SaleCollection
 */
class SaleCollection extends BaseCollection
{
    public $collects = SaleResource::class;
}
