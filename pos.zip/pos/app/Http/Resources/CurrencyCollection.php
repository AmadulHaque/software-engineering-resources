<?php

namespace App\Http\Resources;

/**
 * Class CurrencyCollection
 */
class CurrencyCollection extends BaseCollection
{
    public $collects = CurrencyResource::class;
}
