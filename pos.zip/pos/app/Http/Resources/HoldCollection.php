<?php

namespace App\Http\Resources;

/**
 * Class HoldCollection
 */
class HoldCollection extends BaseCollection
{
    public $collects = HoldResource::class;
}
