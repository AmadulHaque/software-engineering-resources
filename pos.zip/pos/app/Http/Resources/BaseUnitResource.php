<?php

namespace App\Http\Resources;

/**
 * Class BaseUnitResource
 */
class BaseUnitResource extends BaseJsonResource
{
}
