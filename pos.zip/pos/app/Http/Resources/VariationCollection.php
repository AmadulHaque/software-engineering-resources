<?php

namespace App\Http\Resources;


class VariationCollection extends BaseCollection
{
    public $collects = VariationResource::class;
}
