<?php

namespace App\Http\Resources;

class VariationResource extends BaseJsonResource
{

}
