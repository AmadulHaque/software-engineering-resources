<?php

namespace App\Http\Resources;

/**
 * Class QuotationResource
 */
class QuotationResource extends BaseJsonResource
{
}
