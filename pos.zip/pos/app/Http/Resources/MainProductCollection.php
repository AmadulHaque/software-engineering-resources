<?php

namespace App\Http\Resources;

/**
 * Class AdjustmentCollection
 */
class MainProductCollection extends BaseCollection
{
    public $collects = MainProductResource::class;
}
